package com.Cason.MyWebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
